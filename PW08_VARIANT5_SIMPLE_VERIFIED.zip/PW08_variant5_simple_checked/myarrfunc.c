#include <stdio.h>
#include "myarrfunc.h"

int fill_array(int *a, size_t n) {
    size_t i;

    for (i = 0; i < n; i++) {
        printf("a[%zu] = ", i);
        if (scanf("%d", a + i) != 1) {
            return 0;
        }
    }
    return 1;
}

void show_array(int *a, size_t n) {
    size_t i;

    for (i = 0; i < n; i++) {
        printf("a[%zu] = %d, address = %p\n",
               i, *(a + i), (void *)(a + i));
    }
}

/* Function 1: minimum and maximum. */
int find_min_max(int *a, size_t n, int *minimum, int *maximum) {
    size_t i;

    if (n == 0) {
        return 0;
    }

    *minimum = *a;
    *maximum = *a;

    for (i = 1; i < n; i++) {
        if (*(a + i) < *minimum) {
            *minimum = *(a + i);
        }
        if (*(a + i) > *maximum) {
            *maximum = *(a + i);
        }
    }
    return 1;
}

/* Function 12: average of the entire array. */
double find_average(int *a, size_t n) {
    size_t i;
    double sum = 0;

    if (n == 0) {
        return 0;
    }

    for (i = 0; i < n; i++) {
        sum = sum + *(a + i);
    }
    return sum / n;
}

/* Function 29: sum of elements below the average. */
double sum_below_average(int *a, size_t n) {
    size_t i;
    double average = find_average(a, n);
    double result = 0;

    for (i = 0; i < n; i++) {
        if (*(a + i) < average) {
            result = result + *(a + i);
        }
    }
    return result;
}
