#include <stdio.h>
#include "myarrfunc.h"

int main(void) {
    int a[100];
    int n = 0;
    int filled = 0;
    int minimum, maximum;
    char choice = ' ';

    while (choice != 'g') {
        printf("\na - Set array size\n");
        printf("b - Fill array\n");
        printf("c - Show array and addresses\n");
        printf("d - Minimum and maximum (1)\n");
        printf("e - Average (12)\n");
        printf("f - Sum below average (29)\n");
        printf("g - Exit\n");
        printf("Choice: ");

        if (scanf(" %c", &choice) != 1) {
            break;
        }

        if (choice == 'a') {
            printf("Enter size (1..100): ");
            if (scanf("%d", &n) != 1) {
                printf("Input error.\n");
                return 1;
            }
            if (n < 1 || n > 100) {
                printf("Invalid size.\n");
                n = 0;
            }
            filled = 0;
        }
        else if (choice == 'b') {
            if (n == 0) {
                printf("Set array size first.\n");
            }
            else if (fill_array(a, n) == 0) {
                printf("Input error.\n");
                return 1;
            }
            else {
                filled = 1;
            }
        }
        else if (choice >= 'c' && choice <= 'f' && filled == 0) {
            printf("Fill the array first.\n");
        }
        else if (choice == 'c') {
            show_array(a, n);
        }
        else if (choice == 'd') {
            if (find_min_max(a, n, &minimum, &maximum) == 1) {
                printf("Minimum = %d\n", minimum);
                printf("Maximum = %d\n", maximum);
            }
        }
        else if (choice == 'e') {
            printf("Average = %.2f\n", find_average(a, n));
        }
        else if (choice == 'f') {
            printf("Sum below average = %.0f\n", sum_below_average(a, n));
        }
        else if (choice != 'g') {
            printf("Unknown choice.\n");
        }
    }

    return 0;
}
