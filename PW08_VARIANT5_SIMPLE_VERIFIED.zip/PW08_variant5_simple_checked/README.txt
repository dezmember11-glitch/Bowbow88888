PRACTICAL WORK 8 — VARIANT 5

Files: main.c, myarrfunc.h, myarrfunc.c
Three required functions:
  #1  Minimum and maximum of an array
  #12 Average of all array elements
  #29 Sum of elements below the average

Linux GCC:
  gcc -std=c11 -Wall -Wextra -Wpedantic main.c myarrfunc.c -o pw8
  ./pw8

Example input, enter each item when prompted:
a
5
b
1
3
5
7
9
d
e
f
g

Expected results:
Minimum = 1
Maximum = 9
Average = 5.00
Sum below average = 4

Note: all 3 source files belong to ONE executable program.
