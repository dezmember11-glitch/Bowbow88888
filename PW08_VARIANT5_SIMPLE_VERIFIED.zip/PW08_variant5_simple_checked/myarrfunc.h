#include <stddef.h>

int fill_array(int *a, size_t n);
void show_array(int *a, size_t n);
int find_min_max(int *a, size_t n, int *minimum, int *maximum);
double find_average(int *a, size_t n);
double sum_below_average(int *a, size_t n);
